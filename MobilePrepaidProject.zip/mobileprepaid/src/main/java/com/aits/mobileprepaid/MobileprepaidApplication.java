package com.aits.mobileprepaid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MobileprepaidApplication {

	public static void main(String[] args) {
		SpringApplication.run(MobileprepaidApplication.class, args);
	}

}
