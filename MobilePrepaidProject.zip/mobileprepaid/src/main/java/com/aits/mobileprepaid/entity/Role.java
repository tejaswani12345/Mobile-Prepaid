package com.aits.mobileprepaid.entity;

public enum Role {

	ADMIN,USER
}
